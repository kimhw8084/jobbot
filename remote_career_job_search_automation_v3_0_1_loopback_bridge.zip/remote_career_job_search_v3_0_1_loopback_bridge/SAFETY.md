# JobBot v3.0.1 Safety

The browser automation is intentionally read-only for discovery and research.

It may navigate normal job-search pages, scroll/paginate, open job-detail pages, read rendered job data, and send structured records to the local ledger.

It does **not** submit applications, fill employer application forms, upload files, solve CAPTCHAs, bypass Cloudflare/security challenges, alter fingerprints, rotate proxies, exploit hidden APIs, export cookies/passwords, or execute downloaded content.

The local Python bridge binds only to `127.0.0.1`, uses an ephemeral port and a random per-run token, and is terminated when the launcher exits. The extension has no need for the Chrome `nativeMessaging` permission in v3.0.1.

If a platform presents a verification/challenge page, that platform is checkpointed/paused rather than bypassed. Other platforms can continue.
