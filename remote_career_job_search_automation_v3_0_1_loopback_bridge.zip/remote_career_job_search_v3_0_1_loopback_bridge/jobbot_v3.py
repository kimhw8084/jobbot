#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import re
import sqlite3
import time
import urllib.parse
from pathlib import Path
from typing import Any

import jobbot as j

V3_VERSION = "3.0.1-loopback"
EXTENSION_ID = "jfdlmelgonjhgnabpbipjefgamedpgfb"
NATIVE_HOST_NAME = "com.jobbot.local"
PLATFORMS = ("linkedin", "indeed", "glassdoor")
PLATFORM_PRIORITY = {"linkedin": 0, "indeed": 1, "glassdoor": 2}


def base_dir() -> Path:
    return Path(__file__).resolve().parent


def paths(base: Path) -> tuple[Path, Path, Path, dict[str, Any], dict[str, Any]]:
    cfg = j.load_toml(base / "config.toml")
    strategy = j.load_toml(base / "strategy.toml")
    db = j.abs_path(base, cfg.get("run", {}).get("db_path", "data/jobs.sqlite3"))
    out = j.abs_path(base, cfg.get("run", {}).get("output_dir", "out"))
    out.mkdir(parents=True, exist_ok=True)
    return db, out, base / "extension", cfg, strategy


def table_columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {str(r[1]) for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}


def ensure_col(conn: sqlite3.Connection, table: str, name: str, ddl: str) -> None:
    if name not in table_columns(conn, table):
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")


def init_browser_schema(conn: sqlite3.Connection) -> None:
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS browser_runs(
      browser_run_id INTEGER PRIMARY KEY AUTOINCREMENT,
      version TEXT NOT NULL,
      mode TEXT NOT NULL,
      platform TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued',
      created_at TEXT NOT NULL,
      started_at TEXT,
      completed_at TEXT,
      stop_requested INTEGER NOT NULL DEFAULT 0,
      auth_status TEXT NOT NULL DEFAULT 'unchecked',
      jobs_new INTEGER NOT NULL DEFAULT 0,
      jobs_updated INTEGER NOT NULL DEFAULT 0,
      jobs_unchanged INTEGER NOT NULL DEFAULT 0,
      jobs_recorded INTEGER NOT NULL DEFAULT 0,
      tasks_completed INTEGER NOT NULL DEFAULT 0,
      tasks_challenged INTEGER NOT NULL DEFAULT 0,
      notes TEXT NOT NULL DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS browser_search_tasks(
      task_id INTEGER PRIMARY KEY AUTOINCREMENT,
      browser_run_id INTEGER NOT NULL,
      platform TEXT NOT NULL,
      query_text TEXT NOT NULL,
      remote_required INTEGER NOT NULL DEFAULT 1,
      window_days INTEGER NOT NULL,
      sort_order TEXT NOT NULL DEFAULT 'date',
      search_url TEXT NOT NULL,
      max_results INTEGER,
      status TEXT NOT NULL DEFAULT 'queued',
      created_at TEXT NOT NULL,
      started_at TEXT,
      completed_at TEXT,
      results_seen INTEGER NOT NULL DEFAULT 0,
      jobs_recorded INTEGER NOT NULL DEFAULT 0,
      jobs_new INTEGER NOT NULL DEFAULT 0,
      jobs_updated INTEGER NOT NULL DEFAULT 0,
      jobs_unchanged INTEGER NOT NULL DEFAULT 0,
      pages_visited INTEGER NOT NULL DEFAULT 0,
      challenge_reason TEXT NOT NULL DEFAULT '',
      checkpoint_json TEXT NOT NULL DEFAULT '{}',
      FOREIGN KEY(browser_run_id) REFERENCES browser_runs(browser_run_id)
    );
    CREATE INDEX IF NOT EXISTS idx_browser_tasks_run_status ON browser_search_tasks(browser_run_id,status,task_id);
    CREATE TABLE IF NOT EXISTS browser_events(
      event_id INTEGER PRIMARY KEY AUTOINCREMENT,
      browser_run_id INTEGER,
      task_id INTEGER,
      event_at TEXT NOT NULL,
      event_type TEXT NOT NULL,
      message TEXT NOT NULL DEFAULT '',
      payload_json TEXT NOT NULL DEFAULT '{}'
    );
    CREATE TABLE IF NOT EXISTS browser_platform_runs(
      browser_run_id INTEGER NOT NULL,
      platform TEXT NOT NULL,
      auth_status TEXT NOT NULL DEFAULT 'unchecked',
      auth_reason TEXT NOT NULL DEFAULT '',
      auth_checked_at TEXT,
      tasks_total INTEGER NOT NULL DEFAULT 0,
      tasks_completed INTEGER NOT NULL DEFAULT 0,
      tasks_challenged INTEGER NOT NULL DEFAULT 0,
      tasks_failed INTEGER NOT NULL DEFAULT 0,
      jobs_recorded INTEGER NOT NULL DEFAULT 0,
      PRIMARY KEY(browser_run_id,platform)
    );
    """)
    # Safe additive migration from Gate A-D schemas.
    ensure_col(conn, "browser_search_tasks", "search_profile", "TEXT NOT NULL DEFAULT ''")
    ensure_col(conn, "browser_search_tasks", "career_lane", "TEXT NOT NULL DEFAULT ''")
    ensure_col(conn, "browser_search_tasks", "priority", "INTEGER NOT NULL DEFAULT 99")
    ensure_col(conn, "browser_search_tasks", "exhausted", "INTEGER NOT NULL DEFAULT 0")
    ensure_col(conn, "browser_search_tasks", "attempts", "INTEGER NOT NULL DEFAULT 0")
    ensure_col(conn, "browser_search_tasks", "last_error", "TEXT NOT NULL DEFAULT ''")
    ensure_col(conn, "browser_search_tasks", "skip_old_cards", "INTEGER NOT NULL DEFAULT 1")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_browser_tasks_run_platform_status ON browser_search_tasks(browser_run_id,platform,status,priority,task_id)")
    conn.commit()


def slugify(s: str) -> str:
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", s.lower())).strip("-") or "jobs"


def indeed_search_url(query: str, days: int) -> str:
    q = urllib.parse.urlencode({"q": query, "l": "Remote", "fromage": str(max(1, days)), "sort": "date"})
    return f"https://www.indeed.com/jobs?{q}"


def linkedin_search_url(query: str, days: int) -> str:
    secs = max(1, days) * 86400
    params = {
        "keywords": query,
        "location": "United States",
        "f_WT": "2",            # remote
        "f_TPR": f"r{secs}",    # time posted range
        "sortBy": "DD",         # most recent
    }
    return "https://www.linkedin.com/jobs/search/?" + urllib.parse.urlencode(params)


def glassdoor_search_url(query: str, days: int) -> str:
    # Glassdoor exposes Remote result pages with a stable URL family.  Date is
    # enforced from card/detail age by the extension because the public result
    # URL does not reliably preserve a date filter.
    slug = slugify(query)
    end = 7 + len(query)
    return f"https://www.glassdoor.com/Job/remote-{slug}-jobs-SRCH_IL.0,6_IS11047_KO7,{end}.htm"


def search_url(platform: str, query: str, days: int) -> str:
    if platform == "indeed": return indeed_search_url(query, days)
    if platform == "linkedin": return linkedin_search_url(query, days)
    if platform == "glassdoor": return glassdoor_search_url(query, days)
    raise ValueError(f"unsupported platform: {platform}")


def iter_strategy_tasks(strategy: dict[str, Any], mode: str, platforms: list[str]) -> list[dict[str, Any]]:
    tasks: list[dict[str, Any]] = []
    seen: set[tuple[str, str, int]] = set()
    for profile in strategy.get("searches", []):
        if not profile.get("enabled", True):
            continue
        pri = int(profile.get("priority", 99))
        # FAST keeps P0/P1. DEEP deliberately includes every enabled profile.
        if mode == "fast" and pri > 1:
            continue
        if mode == "deep":
            days = int(profile.get("bootstrap_backfill_days", 30) or 30)
        else:
            hours = float(profile.get("normal_freshness_hours", 168) or 168)
            days = max(1, int(math.ceil(hours / 24.0)))
        for kw in profile.get("keywords", []):
            query = j.clean_text(kw)
            if not query: continue
            for platform in platforms:
                key = (platform, query.lower(), days)
                if key in seen: continue
                seen.add(key)
                tasks.append({
                    "platform": platform,
                    "query_text": query,
                    "window_days": days,
                    "search_profile": j.clean_text(profile.get("name")),
                    "career_lane": j.clean_text(profile.get("career_lane")),
                    "priority": pri,
                    "search_url": search_url(platform, query, days),
                })
    tasks.sort(key=lambda x: (PLATFORM_PRIORITY.get(x["platform"], 99), x["priority"], x["search_profile"], x["query_text"].lower()))
    return tasks


def enqueue_production(base: Path, mode: str = "deep", platforms: list[str] | None = None) -> int:
    db, _, _, _, strategy = paths(base)
    chosen = platforms or list(PLATFORMS)
    bad = [p for p in chosen if p not in PLATFORMS]
    if bad: raise ValueError(f"unsupported platform(s): {', '.join(bad)}")
    tasks = iter_strategy_tasks(strategy, mode, chosen)
    store = j.PrecisionStore(db); init_browser_schema(store.conn)
    now = j.now_iso()
    cur = store.conn.execute(
        "INSERT INTO browser_runs(version,mode,platform,status,created_at,notes) VALUES(?,?,?,?,?,?)",
        (V3_VERSION, mode, ",".join(chosen), "queued", now,
         f"Platform-first exhaustive search. {len(tasks)} persistent tasks; no strategic result-count limit."),
    )
    rid = int(cur.lastrowid)
    for platform in chosen:
        n = sum(1 for t in tasks if t["platform"] == platform)
        store.conn.execute(
            "INSERT OR REPLACE INTO browser_platform_runs(browser_run_id,platform,tasks_total) VALUES(?,?,?)",
            (rid, platform, n),
        )
    for t in tasks:
        store.conn.execute(
            """INSERT INTO browser_search_tasks(
              browser_run_id,platform,query_text,remote_required,window_days,sort_order,search_url,max_results,status,created_at,
              search_profile,career_lane,priority,skip_old_cards
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (rid, t["platform"], t["query_text"], 1, t["window_days"], "date", t["search_url"], None, "queued", now,
             t["search_profile"], t["career_lane"], t["priority"], 1),
        )
    store.conn.commit(); store.close()
    return rid


def enqueue_gate(base: Path, platform: str = "indeed", days: int = 7, max_results: int = 20) -> int:
    queries = ["patient enrollment specialist", "patient access specialist", "healthcare operations coordinator"]
    db, _, _, _, _ = paths(base)
    store = j.PrecisionStore(db); init_browser_schema(store.conn); now = j.now_iso()
    rid = int(store.conn.execute(
        "INSERT INTO browser_runs(version,mode,platform,status,created_at,notes) VALUES(?,?,?,?,?,?)",
        (V3_VERSION, "acceptance", platform, "queued", now, "Acceptance: auth + pagination + multi-query"),
    ).lastrowid)
    store.conn.execute("INSERT OR REPLACE INTO browser_platform_runs(browser_run_id,platform,tasks_total) VALUES(?,?,?)", (rid, platform, len(queries)))
    for q in queries:
        store.conn.execute(
            """INSERT INTO browser_search_tasks(browser_run_id,platform,query_text,remote_required,window_days,sort_order,search_url,max_results,status,created_at,search_profile,career_lane,priority)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (rid, platform, q, 1, days, "date", search_url(platform, q, days), max_results, "queued", now,
             "acceptance-smoke", "healthcare_access", 0),
        )
    store.conn.commit(); store.close(); return rid


def show_status(base: Path, rid: int | None = None, verbose: bool = False) -> int:
    db, _, _, _, _ = paths(base)
    if not db.exists(): print("No ledger yet."); return 1
    conn=sqlite3.connect(db); conn.row_factory=sqlite3.Row; init_browser_schema(conn)
    r=conn.execute("SELECT * FROM browser_runs ORDER BY browser_run_id DESC LIMIT 1").fetchone() if rid is None else conn.execute("SELECT * FROM browser_runs WHERE browser_run_id=?",(rid,)).fetchone()
    if not r: print("No browser run found."); conn.close(); return 1
    print(f"Browser run #{r['browser_run_id']} | {r['mode']} | {r['status']} | platforms={r['platform']}")
    print(f"Jobs recorded={r['jobs_recorded']} new={r['jobs_new']} updated={r['jobs_updated']} unchanged={r['jobs_unchanged']}")
    for p in conn.execute("SELECT * FROM browser_platform_runs WHERE browser_run_id=? ORDER BY CASE platform WHEN 'linkedin' THEN 0 WHEN 'indeed' THEN 1 ELSE 2 END",(r['browser_run_id'],)):
        print(f"  {p['platform']:<10} auth={p['auth_status']:<16} tasks={p['tasks_completed']}/{p['tasks_total']} challenged={p['tasks_challenged']} failed={p['tasks_failed']} jobs={p['jobs_recorded']}")
    counts=conn.execute("SELECT status,COUNT(*) n FROM browser_search_tasks WHERE browser_run_id=? GROUP BY status ORDER BY status",(r['browser_run_id'],)).fetchall()
    print("Tasks: " + ", ".join(f"{x['status']}={x['n']}" for x in counts))
    if verbose:
        for t in conn.execute("SELECT * FROM browser_search_tasks WHERE browser_run_id=? ORDER BY platform,priority,task_id",(r['browser_run_id'],)):
            print(f"  [{t['task_id']}] {t['platform']:<9} {t['status']:<14} pages={t['pages_visited']:<3} seen={t['results_seen']:<5} saved={t['jobs_recorded']:<4} {t['query_text']}")
    conn.close(); return 0


def request_stop(base: Path, rid: int | None = None) -> int:
    db, _, _, _, _ = paths(base); conn=sqlite3.connect(db); conn.row_factory=sqlite3.Row; init_browser_schema(conn)
    if rid is None:
        r=conn.execute("SELECT browser_run_id FROM browser_runs WHERE status IN ('queued','running') ORDER BY browser_run_id DESC LIMIT 1").fetchone()
        if not r: print("No active browser run."); conn.close(); return 1
        rid=int(r[0])
    conn.execute("UPDATE browser_runs SET stop_requested=1,notes=trim(notes || ' stop requested') WHERE browser_run_id=?",(rid,)); conn.commit(); conn.close()
    print(f"Stop requested for browser run #{rid}."); return 0


def report(base: Path, rid: int | None = None) -> int:
    db,out,_,_,_=paths(base); conn=sqlite3.connect(db); conn.row_factory=sqlite3.Row; init_browser_schema(conn)
    r=conn.execute("SELECT * FROM browser_runs ORDER BY browser_run_id DESC LIMIT 1").fetchone() if rid is None else conn.execute("SELECT * FROM browser_runs WHERE browser_run_id=?",(rid,)).fetchone()
    if not r: print("No browser run found."); conn.close(); return 1
    lines=[f"# JobBot v3 Platform-First Search Report — Run {r['browser_run_id']}","",f"- Mode: **{r['mode']}**",f"- Status: **{r['status']}**",f"- Platforms: **{r['platform']}**",f"- Jobs recorded: **{r['jobs_recorded']}** (new {r['jobs_new']}, updated {r['jobs_updated']}, unchanged {r['jobs_unchanged']})","","## Platforms",""]
    for p in conn.execute("SELECT * FROM browser_platform_runs WHERE browser_run_id=? ORDER BY CASE platform WHEN 'linkedin' THEN 0 WHEN 'indeed' THEN 1 ELSE 2 END",(r['browser_run_id'],)):
        lines += [f"### {p['platform'].title()}",f"- Authentication: {p['auth_status']}",f"- Tasks completed: {p['tasks_completed']} / {p['tasks_total']}",f"- Challenged: {p['tasks_challenged']}",f"- Failed: {p['tasks_failed']}",f"- Jobs recorded: {p['jobs_recorded']}",""]
    lines += ["## Task summary",""]
    for row in conn.execute("SELECT platform,status,COUNT(*) n,SUM(results_seen) seen,SUM(jobs_recorded) saved,SUM(pages_visited) pages FROM browser_search_tasks WHERE browser_run_id=? GROUP BY platform,status ORDER BY platform,status",(r['browser_run_id'],)):
        lines.append(f"- {row['platform']} / {row['status']}: {row['n']} task(s), pages={row['pages'] or 0}, results_seen={row['seen'] or 0}, jobs_recorded={row['saved'] or 0}")
    lines += ["","## Important","","> Result-count limits are not used in production mode. A task ends on platform/search exhaustion, age-boundary logic, challenge, failure, or explicit stop.",""]
    p=out/f"v3_run_{r['browser_run_id']}_report.md"; p.write_text("\n".join(lines),encoding="utf-8"); conn.close(); print(p); return 0


def wait_run(base: Path, rid: int, interval: float=5.0, timeout_minutes: int=1440) -> int:
    db,_,_,_,_=paths(base); deadline=time.time()+max(1,timeout_minutes)*60; last=None
    while time.time()<deadline:
        conn=sqlite3.connect(db); conn.row_factory=sqlite3.Row; init_browser_schema(conn)
        r=conn.execute("SELECT * FROM browser_runs WHERE browser_run_id=?",(rid,)).fetchone()
        if not r: conn.close(); print("Run not found."); return 2
        counts=tuple((x['platform'],x['status'],x['n'],x['saved']) for x in conn.execute("SELECT platform,status,COUNT(*) n,SUM(jobs_recorded) saved FROM browser_search_tasks WHERE browser_run_id=? GROUP BY platform,status ORDER BY platform,status",(rid,)))
        snap=(r['status'],r['jobs_recorded'],r['jobs_new'],r['jobs_updated'],counts)
        if snap!=last:
            print(f"[run {rid}] {r['status']} | recorded={r['jobs_recorded']} new={r['jobs_new']} updated={r['jobs_updated']} unchanged={r['jobs_unchanged']}")
            for x in counts: print(f"  {x[0]:<10} {x[1]:<14} tasks={x[2]:<4} jobs={x[3] or 0}")
            last=snap
        final=r['status'] in {'completed','partial','stopped','failed'}; conn.close()
        if final: return 0 if r['status']=='completed' else 1
        time.sleep(max(.75,interval))
    print(f"Timed out waiting for run #{rid}. The run remains checkpointed and can be resumed.")
    return 3


def install_check(base: Path) -> int:
    ok=True
    print(f"Extension ID: {EXTENSION_ID}")
    print(f"Extension folder: {base/'extension'}")
    bridge=base/'jobbot_bridge.py'
    if not bridge.exists():
        print("  FAIL: loopback bridge missing")
        ok=False
    else:
        print(f"Loopback bridge: {bridge}")
    manifest=base/'extension'/'manifest.json'
    try:
        d=json.loads(manifest.read_text())
        if d.get('manifest_version')!=3: print("  FAIL: extension manifest is not MV3"); ok=False
        if 'http://127.0.0.1/*' not in d.get('host_permissions',[]): print("  FAIL: loopback host permission missing"); ok=False
        if 'nativeMessaging' in d.get('permissions',[]): print("  FAIL: obsolete nativeMessaging permission still present"); ok=False
    except Exception as e:
        print(f"  FAIL: invalid extension manifest: {e}")
        ok=False
    return 0 if ok else 1


def self_test(base: Path) -> int:
    import tempfile
    _,_,_,cfg,strategy=paths(base)
    tasks=iter_strategy_tasks(strategy,'deep',list(PLATFORMS))
    unique_searches=set()
    for s0 in strategy.get('searches',[]):
        if not s0.get('enabled',True): continue
        days0=int(s0.get('bootstrap_backfill_days',30) or 30)
        for x in s0.get('keywords',[]):
            q0=j.clean_text(x).lower()
            if q0: unique_searches.add((q0,days0))
    keyword_count=len(unique_searches)
    expected=keyword_count*3
    assert len(tasks)==expected,(len(tasks),expected)
    assert all(t['search_url'].startswith('https://') for t in tasks)
    assert all(t['platform'] in PLATFORMS for t in tasks)
    assert 'f_WT=2' in linkedin_search_url('patient access specialist',7)
    assert 'fromage=7' in indeed_search_url('patient access specialist',7)
    assert '/Job/remote-patient-access-specialist-jobs-' in glassdoor_search_url('patient access specialist',7)
    with tempfile.TemporaryDirectory() as td:
        p=Path(td); s=j.PrecisionStore(p/'jobs.sqlite3'); init_browser_schema(s.conn); now=j.now_iso()
        rid=int(s.conn.execute("INSERT INTO browser_runs(version,mode,platform,status,created_at) VALUES(?,?,?,?,?)",(V3_VERSION,'test','indeed','running',now)).lastrowid)
        tid=int(s.conn.execute("INSERT INTO browser_search_tasks(browser_run_id,platform,query_text,window_days,search_url,status,created_at) VALUES(?,?,?,?,?,?,?)",(rid,'indeed','patient enrollment specialist',7,indeed_search_url('patient enrollment specialist',7),'running',now)).lastrowid)
        job=j.Job(source_site='indeed',source_job_id='abc123',canonical_url='https://www.indeed.com/viewjob?jk=abc123',apply_url='https://www.indeed.com/viewjob?jk=abc123',title='Patient Enrollment Specialist',company='Example Health',location_raw='Remote',remote_status='remote',employment_type='Full-time',posted_at=now,description='Remote healthcare patient enrollment and onboarding. Required Qualifications: 2 years relevant experience. HIPAA documentation and Excel.',raw={'browser_task_id':tid})
        setattr(job,'_mode','deep'); j.score_job(job,strategy,cfg.get('candidate',{})); a=s.upsert(job); b=s.upsert(job); job.description+=' Updated workflow documentation.'; setattr(job,'_mode','deep'); j.score_job(job,strategy,cfg.get('candidate',{})); c=s.upsert(job)
        assert (a,b,c)==('new','unchanged','updated'),(a,b,c); s.close()
    print(f"V3 SELF-TEST PASSED — {keyword_count} researched keywords -> {expected} exhaustive Big-3 tasks in deep mode")
    return 0


def main() -> int:
    ap=argparse.ArgumentParser(description='JobBot v3 normal-Chrome platform-first controller')
    sub=ap.add_subparsers(dest='cmd',required=True)
    q=sub.add_parser('enqueue-production'); q.add_argument('--mode',choices=['fast','deep'],default='deep'); q.add_argument('--platform',action='append',choices=list(PLATFORMS),help='Repeat to select platforms; default all three')
    g=sub.add_parser('enqueue-acceptance'); g.add_argument('--platform',choices=list(PLATFORMS),default='indeed'); g.add_argument('--days',type=int,default=7); g.add_argument('--max-results',type=int,default=20)
    s=sub.add_parser('status'); s.add_argument('--run-id',type=int); s.add_argument('--verbose',action='store_true')
    x=sub.add_parser('stop'); x.add_argument('--run-id',type=int)
    r=sub.add_parser('report'); r.add_argument('--run-id',type=int)
    w=sub.add_parser('wait'); w.add_argument('--run-id',type=int,required=True); w.add_argument('--interval',type=float,default=5.0); w.add_argument('--timeout-minutes',type=int,default=1440)
    sub.add_parser('install-check'); sub.add_parser('self-test')
    args=ap.parse_args(); base=base_dir()
    if args.cmd=='enqueue-production': rid=enqueue_production(base,args.mode,args.platform); print(rid); return 0
    if args.cmd=='enqueue-acceptance': rid=enqueue_gate(base,args.platform,max(1,args.days),max(1,min(200,args.max_results))); print(rid); return 0
    if args.cmd=='status': return show_status(base,args.run_id,args.verbose)
    if args.cmd=='stop': return request_stop(base,args.run_id)
    if args.cmd=='report': return report(base,args.run_id)
    if args.cmd=='wait': return wait_run(base,args.run_id,args.interval,args.timeout_minutes)
    if args.cmd=='install-check': return install_check(base)
    if args.cmd=='self-test': return self_test(base)
    return 2

if __name__=='__main__': raise SystemExit(main())
