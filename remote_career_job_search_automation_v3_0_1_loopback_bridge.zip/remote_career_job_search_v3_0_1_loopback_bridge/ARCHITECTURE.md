# v3.0.1 Architecture — Platform-First Normal Chrome

```text
Normal installed Google Chrome
        │
        ▼
JobBot Manifest V3 extension
        │
        │ tokenized HTTP RPC to 127.0.0.1 only
        ▼
jobbot_bridge.py
        │
        ▼
Python scoring + SQLite ledger
        │
        ├── canonical jobs
        ├── immutable versions / diffs
        ├── source sightings
        ├── platform search tasks/checkpoints
        └── application funnel
```

## Discovery hierarchy

1. LinkedIn — primary platform search
2. Indeed — primary platform search
3. Glassdoor — primary platform search
4. Employer ATS/career pages — canonical verification + supplemental discovery
5. Other boards/public remote feeds — supplemental recall

Employer watchlists never define or restrict the market universe.

## Search task model

Each `(platform, keyword, age window)` is a persistent task. Production tasks use `max_results = NULL`. The extension keeps traversing normal visible search results until no further result page/batch is reachable, an age/search boundary is met, a site challenge occurs, a real failure occurs, or the user explicitly stops the run.

Overlapping searches are expected and desirable. Dedupe happens after discovery.

## Local bridge

v3.0.1 deliberately does not depend on Chrome Native Messaging. The launcher starts the bridge directly using the package's `.venv/bin/python`, which removes macOS host-registration and iCloud executable-path failure modes.

Security:
- binds only `127.0.0.1`;
- ephemeral OS-selected port;
- cryptographically random token per launcher run;
- token required for every RPC;
- 4 MiB request cap;
- bridge process ends with the launcher.
