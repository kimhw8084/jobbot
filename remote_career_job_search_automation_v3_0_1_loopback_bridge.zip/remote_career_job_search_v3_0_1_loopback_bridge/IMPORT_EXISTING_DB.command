#!/bin/bash
set -euo pipefail
BASE="$(cd "$(dirname "$0")" && pwd)"
TARGET="$BASE/data/jobs.sqlite3"
echo "Paste the full path to your existing jobs.sqlite3, then press ENTER:"
read -r OLD
OLD="${OLD/#\~/$HOME}"
if [[ ! -f "$OLD" ]]; then
  echo "File not found: $OLD"
  exit 2
fi
mkdir -p "$BASE/data"
if [[ -f "$TARGET" ]]; then
  TS=$(date +%Y%m%d_%H%M%S)
  cp "$TARGET" "$BASE/data/jobs_before_import_$TS.sqlite3"
  echo "Backed up current v3 ledger first."
fi
cp "$OLD" "$TARGET"
echo "Imported existing ledger to: $TARGET"
PY="$BASE/.venv/bin/python"; [[ -x "$PY" ]] || PY="$(command -v python3)"
"$PY" "$BASE/jobbot_v3.py" self-test >/dev/null
echo "Import complete. Existing history will be migrated lazily when v3 opens the ledger."
read -r -p "Press ENTER..." _
