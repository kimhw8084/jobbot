#!/usr/bin/env python3
from __future__ import annotations

import json
import sqlite3
import struct
import sys
import traceback
from pathlib import Path
from typing import Any

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import jobbot as j
import jobbot_v3 as v3
j.VERSION=v3.V3_VERSION; j.c.VERSION=v3.V3_VERSION


def log(msg:str)->None: print(f"[jobbot-native] {msg}",file=sys.stderr,flush=True)

def read_message()->dict[str,Any]|None:
    raw_len=sys.stdin.buffer.read(4)
    if not raw_len:return None
    if len(raw_len)!=4:raise RuntimeError('truncated native message length')
    n=struct.unpack('=I',raw_len)[0]
    if n<=0 or n>64*1024*1024:raise RuntimeError(f'invalid inbound message size: {n}')
    raw=sys.stdin.buffer.read(n)
    if len(raw)!=n:raise RuntimeError('truncated native message body')
    obj=json.loads(raw.decode('utf-8'));return obj if isinstance(obj,dict) else {'action':'invalid'}

def write_message(obj:dict[str,Any])->None:
    raw=json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    if len(raw)>1024*1024:raise RuntimeError('outbound native message exceeds 1 MiB')
    sys.stdout.buffer.write(struct.pack('=I',len(raw)));sys.stdout.buffer.write(raw);sys.stdout.buffer.flush()

def open_store():
    db,out,_,cfg,strategy=v3.paths(BASE);store=j.PrecisionStore(db);v3.init_browser_schema(store.conn);return store,cfg,strategy,out

def event(conn,run_id,task_id,typ,msg='',payload=None):
    conn.execute("INSERT INTO browser_events(browser_run_id,task_id,event_at,event_type,message,payload_json) VALUES(?,?,?,?,?,?)",(run_id,task_id,j.now_iso(),typ,j.clean_text(msg),json.dumps(payload or {},ensure_ascii=False)))

def get_run(conn,rid):return conn.execute("SELECT * FROM browser_runs WHERE browser_run_id=?",(rid,)).fetchone()

def platform_order_sql()->str:return "CASE platform WHEN 'linkedin' THEN 0 WHEN 'indeed' THEN 1 WHEN 'glassdoor' THEN 2 ELSE 99 END"

def handle(msg:dict[str,Any])->dict[str,Any]:
    action=str(msg.get('action') or '')
    store,cfg,strategy,out=open_store();conn=store.conn
    try:
        if action=='ping': return {'ok':True,'version':v3.V3_VERSION}
        if action=='begin_run':
            rid=int(msg.get('run_id') or 0);r=get_run(conn,rid)
            if not r:return {'ok':False,'error':'run_not_found'}
            if int(r['stop_requested'] or 0):return {'ok':False,'error':'stop_requested'}
            conn.execute("UPDATE browser_runs SET status='running',started_at=COALESCE(started_at,?) WHERE browser_run_id=?",(j.now_iso(),rid));event(conn,rid,None,'run_started','normal Chrome platform-first run started');conn.commit();return {'ok':True}
        if action=='platform_auth_result':
            rid=int(msg.get('run_id') or 0);platform=j.clean_text(msg.get('platform'));ok=bool(msg.get('authenticated'));reason=j.clean_text(msg.get('reason') or '')
            conn.execute("UPDATE browser_platform_runs SET auth_status=?,auth_reason=?,auth_checked_at=? WHERE browser_run_id=? AND platform=?",('verified' if ok else 'not_authenticated',reason,j.now_iso(),rid,platform))
            if not ok:
                conn.execute("UPDATE browser_search_tasks SET status='auth_required',completed_at=?,last_error=? WHERE browser_run_id=? AND platform=? AND status IN ('queued','running')",(j.now_iso(),reason,rid,platform))
            states=[x['auth_status'] for x in conn.execute("SELECT auth_status FROM browser_platform_runs WHERE browser_run_id=?",(rid,))]
            overall='verified' if states and all(x=='verified' for x in states) else ('partial' if any(x=='verified' for x in states) else 'not_authenticated')
            conn.execute("UPDATE browser_runs SET auth_status=? WHERE browser_run_id=?",(overall,rid));event(conn,rid,None,'auth_verified' if ok else 'auth_failed',f'{platform}: {reason}',msg);conn.commit();return {'ok':True}
        if action=='pause_platform':
            rid=int(msg.get('run_id') or 0); platform=j.clean_text(msg.get('platform')); reason=j.clean_text(msg.get('reason') or 'platform challenge')
            conn.execute("UPDATE browser_platform_runs SET auth_reason=? WHERE browser_run_id=? AND platform=?",(reason,rid,platform))
            rows=conn.execute("SELECT task_id,status FROM browser_search_tasks WHERE browser_run_id=? AND platform=? AND status IN ('queued','running')",(rid,platform)).fetchall()
            for rr in rows:
                conn.execute("UPDATE browser_search_tasks SET status='challenged',completed_at=?,challenge_reason=? WHERE task_id=?",(j.now_iso(),reason,rr['task_id']))
            if rows:
                conn.execute("UPDATE browser_runs SET tasks_challenged=tasks_challenged+? WHERE browser_run_id=?",(len(rows),rid))
                conn.execute("UPDATE browser_platform_runs SET tasks_challenged=tasks_challenged+? WHERE browser_run_id=? AND platform=?",(len(rows),rid,platform))
            event(conn,rid,None,'platform_paused',f'{platform}: {reason}',msg);conn.commit();return {'ok':True,'tasks_paused':len(rows)}
        if action=='next_task':
            rid=int(msg.get('run_id') or 0);r=get_run(conn,rid)
            if not r:return {'ok':False,'error':'run_not_found'}
            if int(r['stop_requested'] or 0):return {'ok':True,'stop':True}
            t=conn.execute(f"SELECT * FROM browser_search_tasks WHERE browser_run_id=? AND status IN ('running','queued') ORDER BY CASE status WHEN 'running' THEN 0 ELSE 1 END,{platform_order_sql()},priority,task_id LIMIT 1",(rid,)).fetchone()
            if not t:return {'ok':True,'done':True}
            if t['status']=='queued':
                conn.execute("UPDATE browser_search_tasks SET status='running',started_at=COALESCE(started_at,?),attempts=attempts+1 WHERE task_id=?",(j.now_iso(),t['task_id']));event(conn,rid,t['task_id'],'task_started',f"{t['platform']}: {t['query_text']}");conn.commit();t=conn.execute("SELECT * FROM browser_search_tasks WHERE task_id=?",(t['task_id'],)).fetchone()
            return {'ok':True,'task':{k:t[k] for k in t.keys()}}
        if action=='record_job':
            rid=int(msg.get('run_id') or 0);tid=int(msg.get('task_id') or 0);raw=msg.get('job') or {}
            if not isinstance(raw,dict):return {'ok':False,'error':'invalid_job'}
            task=conn.execute("SELECT * FROM browser_search_tasks WHERE task_id=? AND browser_run_id=?",(tid,rid)).fetchone()
            if not task:return {'ok':False,'error':'task_not_found'}
            title=j.clean_text(raw.get('title'));company=j.clean_text(raw.get('company'));desc=j.strip_html(raw.get('description') or '')[:180000]
            url=j.canonical_url(j.clean_text(raw.get('canonical_url') or raw.get('url') or ''));sid=j.clean_text(raw.get('source_job_id') or '')
            if not title or not url:return {'ok':False,'error':'insufficient_job_identity'}
            source_site=j.clean_text(task['platform'])
            job=j.Job(source_site=source_site,source_job_id=sid,canonical_url=url,apply_url=j.canonical_url(j.clean_text(raw.get('apply_url') or url)),title=title,company=company,location_raw=j.clean_text(raw.get('location') or 'Remote'),remote_status=j.clean_text(raw.get('remote_status') or 'unknown'),employment_type=j.clean_text(raw.get('employment_type') or ''),salary_text=j.clean_text(raw.get('salary_text') or ''),posted_at=j.clean_text(raw.get('posted_at') or ''),description=desc,category=j.clean_text(raw.get('category') or ''),tags=[j.clean_text(x) for x in(raw.get('tags') or []) if j.clean_text(x)],raw={'browser_v3':True,'browser_run_id':rid,'browser_task_id':tid,'platform':source_site,'query_text':task['query_text'],'search_profile':task['search_profile'],'career_lane':task['career_lane'],'page_url':j.clean_text(raw.get('page_url') or url),'valid_through':j.clean_text(raw.get('valid_through') or ''),'source_payload':raw})
            setattr(job,'_mode','deep');j.score_job(job,strategy,cfg.get('candidate',{}));ledger_status=store.upsert(job,commit=False)
            fields={'new':'jobs_new','updated':'jobs_updated','unchanged':'jobs_unchanged'}
            if ledger_status in fields:
                f=fields[ledger_status];conn.execute(f"UPDATE browser_search_tasks SET jobs_recorded=jobs_recorded+1,{f}={f}+1 WHERE task_id=?",(tid,));conn.execute(f"UPDATE browser_runs SET jobs_recorded=jobs_recorded+1,{f}={f}+1 WHERE browser_run_id=?",(rid,));conn.execute("UPDATE browser_platform_runs SET jobs_recorded=jobs_recorded+1 WHERE browser_run_id=? AND platform=?",(rid,source_site))
            jid=store.resolve_job_id(job);event(conn,rid,tid,'job_recorded',f'{ledger_status}: {job.title} — {job.company}',{'job_id':jid,'ledger_status':ledger_status,'recommendation':job.recommendation});conn.commit();return {'ok':True,'ledger_status':ledger_status,'job_id':jid,'recommendation':job.recommendation,'title':job.title,'company':job.company}
        if action=='job_error':
            rid=int(msg.get('run_id') or 0);tid=int(msg.get('task_id') or 0);event(conn,rid,tid,'job_error',j.clean_text(msg.get('message') or ''),msg);conn.commit();return {'ok':True}
        if action=='task_progress':
            rid=int(msg.get('run_id') or 0);tid=int(msg.get('task_id') or 0);seen=max(0,int(msg.get('results_seen') or 0));pages=max(0,int(msg.get('pages_visited') or 0));cp=msg.get('checkpoint') or {}
            conn.execute("UPDATE browser_search_tasks SET results_seen=MAX(results_seen,?),pages_visited=MAX(pages_visited,?),checkpoint_json=? WHERE task_id=? AND browser_run_id=?",(seen,pages,json.dumps(cp,ensure_ascii=False),tid,rid));conn.commit();return {'ok':True}
        if action=='complete_task':
            rid=int(msg.get('run_id') or 0);tid=int(msg.get('task_id') or 0);status=j.clean_text(msg.get('status') or 'completed');reason=j.clean_text(msg.get('reason') or '');exhausted=1 if bool(msg.get('exhausted')) else 0
            allowed={'completed','test_limit','challenged','failed','stopped','auth_required'};status=status if status in allowed else 'completed'
            t=conn.execute("SELECT platform,status FROM browser_search_tasks WHERE task_id=? AND browser_run_id=?",(tid,rid)).fetchone()
            if not t:return {'ok':False,'error':'task_not_found'}
            conn.execute("UPDATE browser_search_tasks SET status=?,completed_at=?,challenge_reason=?,last_error=?,exhausted=? WHERE task_id=?",(status,j.now_iso(),reason if status=='challenged' else '',reason if status in {'failed','auth_required'} else '',exhausted,tid))
            platform=t['platform']
            if status in {'completed','test_limit'}:
                conn.execute("UPDATE browser_runs SET tasks_completed=tasks_completed+1 WHERE browser_run_id=?",(rid,));conn.execute("UPDATE browser_platform_runs SET tasks_completed=tasks_completed+1 WHERE browser_run_id=? AND platform=?",(rid,platform))
            elif status=='challenged':
                conn.execute("UPDATE browser_runs SET tasks_challenged=tasks_challenged+1 WHERE browser_run_id=?",(rid,));conn.execute("UPDATE browser_platform_runs SET tasks_challenged=tasks_challenged+1 WHERE browser_run_id=? AND platform=?",(rid,platform))
            elif status=='failed':conn.execute("UPDATE browser_platform_runs SET tasks_failed=tasks_failed+1 WHERE browser_run_id=? AND platform=?",(rid,platform))
            event(conn,rid,tid,'task_'+status,reason,msg);conn.commit();return {'ok':True}
        if action=='should_stop':
            rid=int(msg.get('run_id') or 0);r=get_run(conn,rid);return {'ok':True,'stop':bool(r and int(r['stop_requested'] or 0))}
        if action=='finish_run':
            rid=int(msg.get('run_id') or 0);r=get_run(conn,rid)
            if not r:return {'ok':False,'error':'run_not_found'}
            pending=conn.execute("SELECT COUNT(*) n FROM browser_search_tasks WHERE browser_run_id=? AND status IN ('queued','running')",(rid,)).fetchone()['n']
            bad=conn.execute("SELECT COUNT(*) n FROM browser_search_tasks WHERE browser_run_id=? AND status IN ('challenged','failed','auth_required')",(rid,)).fetchone()['n']
            final='stopped' if int(r['stop_requested'] or 0) else ('partial' if pending or bad else 'completed')
            conn.execute("UPDATE browser_runs SET status=?,completed_at=? WHERE browser_run_id=?",(final,j.now_iso(),rid));event(conn,rid,None,'run_finished',final);conn.commit()
            try:j.export_all(store,out,strategy,cfg,'deep')
            except Exception as e:log(f'export warning: {e}')
            return {'ok':True,'status':final}
        if action=='run_status':
            rid=int(msg.get('run_id') or 0);r=get_run(conn,rid)
            if not r:return {'ok':False,'error':'run_not_found'}
            tasks=conn.execute("SELECT task_id,platform,query_text,status,results_seen,jobs_recorded,jobs_new,jobs_updated,jobs_unchanged,pages_visited,challenge_reason,last_error,exhausted FROM browser_search_tasks WHERE browser_run_id=? ORDER BY task_id",(rid,)).fetchall();plats=conn.execute("SELECT * FROM browser_platform_runs WHERE browser_run_id=? ORDER BY CASE platform WHEN 'linkedin' THEN 0 WHEN 'indeed' THEN 1 ELSE 2 END",(rid,)).fetchall();return {'ok':True,'run':{k:r[k] for k in r.keys()},'platforms':[{k:p[k] for k in p.keys()} for p in plats],'tasks':[{k:t[k] for k in t.keys()} for t in tasks]}
        return {'ok':False,'error':'unknown_action','action':action}
    finally:store.close()

def main()->int:
    log(f'started {v3.V3_VERSION}')
    try:
        while True:
            msg=read_message()
            if msg is None:break
            try:resp=handle(msg)
            except Exception as e:log(traceback.format_exc());resp={'ok':False,'error':type(e).__name__,'message':str(e)[:700]}
            if msg.get('request_id'):resp['request_id']=msg.get('request_id')
            write_message(resp)
    except Exception:log(traceback.format_exc());return 1
    return 0
if __name__=='__main__':raise SystemExit(main())
